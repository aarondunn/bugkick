ALTER TABLE `bk_settings_by_project` ADD `defaultStatus` INT( 10 ) UNSIGNED NOT NULL ,
ADD `defaultCompany` INT( 10 ) UNSIGNED NOT NULL;
ALTER TABLE `bk_settings_by_project` CHANGE `user_id` `project_id` INT( 10 ) UNSIGNED NOT NULL;
ALTER TABLE `bk_settings_by_project` CHANGE `defaultAssignee` `defaultAssignee` INT( 10 ) UNSIGNED NOT NULL;
ALTER TABLE `bk_settings_by_project` CHANGE `defaultLabel` `defaultLabel` INT( 10 ) UNSIGNED NULL NOT NULL;
ALTER TABLE `bk_settings_by_project` ADD INDEX ( `project_id` );
TRUNCATE TABLE `bk_settings_by_project`;

CREATE TABLE `bk_settings_by_user` (
`user_id` INT( 10 ) UNSIGNED NOT NULL ,
`defaultAssignee` INT( 10 ) UNSIGNED NOT NULL ,
`defaultLabel` INT( 10 ) UNSIGNED NOT NULL ,
`defaultStatus` INT( 10 ) UNSIGNED NOT NULL ,
`defaultCompany` INT( 10 ) UNSIGNED NOT NULL ,
INDEX ( `user_id` )
) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;