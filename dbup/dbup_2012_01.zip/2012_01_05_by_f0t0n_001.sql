ALTER TABLE `bk_stripe_customer` 
	ADD `expires_at` BIGINT( 20 ) 
	NULL DEFAULT NULL 
	COMMENT 'The time of company''s subscription expiration' 
	AFTER `notified_at` ,
	ADD INDEX ( `expires_at` );