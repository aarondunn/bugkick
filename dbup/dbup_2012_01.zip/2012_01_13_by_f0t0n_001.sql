ALTER TABLE `bk_project` ADD `api_id` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
ADD UNIQUE (`api_id`);