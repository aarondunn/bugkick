ALTER TABLE `bk_bug` 
	ADD `is_created_with_api` TINYINT UNSIGNED 
	NOT NULL DEFAULT '0',
	ADD INDEX ( `is_created_with_api` );

ALTER TABLE `bk_bug` 
	ADD `type` ENUM( 'Bug', 'Feature request', 'Suggestion' ) 
	CHARACTER SET utf8 COLLATE utf8_general_ci 
	NULL DEFAULT NULL 
	COMMENT 'The type of ticket created via BugKick API',
	ADD INDEX ( `type` );

ALTER TABLE `bk_project` 
	ADD `api_ticket_default_assignee` BIGINT( 20 ) 
	NULL DEFAULT NULL ,
	ADD INDEX ( `api_ticket_default_assignee` );