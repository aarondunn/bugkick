ALTER TABLE `bk_company` ADD `api_key` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
ADD INDEX ( `api_key` ) ;