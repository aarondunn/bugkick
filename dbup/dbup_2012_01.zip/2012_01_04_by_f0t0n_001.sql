ALTER TABLE `bk_stripe_customer` CHANGE `payment_interval` `payment_interval` INT( 10 ) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE `bk_stripe_customer` CHANGE `last_payment_time` `last_payment_time` BIGINT( 20 ) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE `bk_stripe_customer` ADD `next_payment_time` BIGINT( 20 ) UNSIGNED NOT NULL DEFAULT '0' AFTER `last_payment_time` ,
ADD INDEX ( `next_payment_time` );