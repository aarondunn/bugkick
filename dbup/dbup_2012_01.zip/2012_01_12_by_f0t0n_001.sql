ALTER TABLE `bugs2`.`bk_company` DROP INDEX `api_key` ,
ADD UNIQUE `api_key` ( `api_key` );