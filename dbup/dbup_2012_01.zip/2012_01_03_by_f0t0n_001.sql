ALTER TABLE `bk_stripe_customer` 
	CHANGE `plan_id` `plan_id` VARCHAR( 255 ) 
	CHARACTER SET utf8 COLLATE utf8_general_ci 
	NULL DEFAULT NULL 
	COMMENT 'Stripe plan''s ID (index)';