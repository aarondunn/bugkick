CREATE TABLE `bk_label_by_project` (
`label_id` INT UNSIGNED NOT NULL ,
`project_id` INT UNSIGNED NOT NULL ,
INDEX ( `label_id` , `project_id` )
) ENGINE = MYISAM ;