ALTER TABLE `user` 
	ADD `facebook_id` VARCHAR( 255 ) 
	CHARACTER SET utf8 COLLATE utf8_general_ci NULL 
	DEFAULT NULL 
	COMMENT 'User''s identifier at the Facebook' AFTER `user_id` ,
	ADD INDEX ( `facebook_id` );