CREATE TABLE `bk_user_group` (
 `group_id` bigint(20) NOT NULL AUTO_INCREMENT,
 `company_id` int(11) NOT NULL,
 `project_id` bigint(20) DEFAULT NULL COMMENT 'If project_id is empty, the group available for all projects',
 `name` varchar(255) NOT NULL,
 `color` varchar(7) DEFAULT NULL,
 `image` varchar(255) DEFAULT NULL,
 PRIMARY KEY (`group_id`),
 KEY `name` (`name`),
 KEY `company_id` (`company_id`),
 KEY `project_id` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `bk_user_by_group` (
 `user_id` bigint(20) NOT NULL,
 `group_id` bigint(20) NOT NULL,
 KEY `user_id` (`user_id`),
 KEY `group_id` (`group_id`),
 KEY `user_id_2` (`user_id`,`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE `bk_user_by_company` ADD INDEX (`user_id`);
ALTER TABLE `bk_user_by_company` ADD INDEX (`company_id`);
ALTER TABLE `bk_user_by_company` ADD INDEX (`user_id` , `company_id`);

ALTER TABLE `bk_status` ADD INDEX ( `company_id` ) 