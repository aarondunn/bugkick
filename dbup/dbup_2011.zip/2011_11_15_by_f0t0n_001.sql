ALTER TABLE `bk_user` 
	ADD `registration_token` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci 
		NULL DEFAULT NULL 
		COMMENT 'Registration verification token.' 
		AFTER `defaultLabel` ,
	ADD INDEX ( `registration_token` );