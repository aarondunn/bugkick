START TRANSACTION;
	DELETE FROM `bk_bug` WHERE `project_id` != '1';

	ALTER TABLE `bk_bug` 
		ADD `prev_number` INT UNSIGNED NOT NULL COMMENT 'Previous bug''s number' AFTER `number` ,
		ADD `next_number` INT UNSIGNED NOT NULL COMMENT 'Next bug''s number' AFTER `prev_number`;

	ALTER TABLE `bk_bug` ADD INDEX ( `prev_number` );
	ALTER TABLE `bk_bug` ADD INDEX ( `next_number` );

	CREATE TEMPORARY TABLE `bk_bug_tmp` SELECT * FROM `bk_bug`;
	UPDATE `bk_bug` AS `t` SET 
	`t`.`number` = (
		SELECT COUNT(`id`) FROM `bk_bug_tmp` AS `tmp`
		WHERE `tmp`.`id` <= `t`.`id` ORDER BY `t`.`id` ASC
	);
	DROP TABLE `bk_bug_tmp`;

	UPDATE `bk_bug` SET 
		`next_number` = `number` + 1, 
		`prev_number` = `number` - 1
	WHERE 1;

	SELECT @min:= MIN(`number`) FROM `bk_bug`;
	SELECT @max:= MAX(`number`) FROM `bk_bug`;

	UPDATE `bk_bug` SET `prev_number` = 0 WHERE `number` = @min;
	UPDATE `bk_bug` SET `next_number` = 0 WHERE `number` = @max;
COMMIT;