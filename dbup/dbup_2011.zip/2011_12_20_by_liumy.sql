CREATE TABLE IF NOT EXISTS `bk_settings_by_project` (
  `user_id` bigint(20) NOT NULL,
  `defaultAssignee` int(11) DEFAULT NULL,
  `defaultLabel` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `bk_settings_by_project`(user_id) select user_id from bk_user;