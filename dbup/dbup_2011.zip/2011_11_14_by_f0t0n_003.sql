ALTER TABLE `bk_project` 
	ADD `url_name` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci 
		NULL DEFAULT NULL 
		COMMENT 'The project name formatted for SEO URLs' AFTER `name` ,
	ADD INDEX ( `url_name` );