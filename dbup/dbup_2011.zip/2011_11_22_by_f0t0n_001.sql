CREATE TABLE IF NOT EXISTS `bk_email_preference` (
  `email_preference_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`email_preference_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

INSERT INTO `bk_email_preferences` (`email_preference_id`, `name`) VALUES
(1, 'New ticket'),
(2, 'Ticket status changes'),
(3, 'New comment'),
(4, 'Due Date reminder');

CREATE TABLE IF NOT EXISTS `bk_user_by_email_preference` (
  `user_id` int(10) unsigned NOT NULL,
  `email_preference_id` int(10) unsigned NOT NULL,
  `state` enum('on','off') NOT NULL,
  KEY `email_preference_id` (`email_preference_id`),
  KEY `user_id` (`user_id`),
  KEY `state` (`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;