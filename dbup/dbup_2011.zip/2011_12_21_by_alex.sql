CREATE TABLE `bk_filter` (
`filter_id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`user_id` INT UNSIGNED NOT NULL ,
`name` VARCHAR( 255 ) NOT NULL ,
`filter` TEXT NOT NULL ,
INDEX ( `user_id` )
) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;