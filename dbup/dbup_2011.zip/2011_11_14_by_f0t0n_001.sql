ALTER TABLE `bk_user` 
	ADD `current_project_id` BIGINT( 20 ) UNSIGNED NULL DEFAULT NULL 
		COMMENT 'An identifier of last selected project (FK)' 
		AFTER `email_preference` ,
	ADD INDEX ( `current_project_id` );