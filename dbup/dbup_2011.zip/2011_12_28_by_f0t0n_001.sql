CREATE TABLE `bk_stripe_customer` (
 `customer_id` varchar(255) NOT NULL COMMENT 'Stripe customer ID (PK, varchar)',
 `user_id` bigint(20) unsigned NOT NULL COMMENT 'BugKick user''s ID (FK, unique bigint)',
 PRIMARY KEY (`customer_id`),
 UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stripe customers';