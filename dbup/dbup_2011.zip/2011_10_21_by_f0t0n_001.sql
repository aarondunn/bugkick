ALTER TABLE `user` 
	ADD `salt` VARCHAR( 255 ) 
	CHARACTER SET utf8 
	COLLATE utf8_general_ci 
	NULL DEFAULT NULL 
	AFTER `password`;

ALTER TABLE `user` 
	ADD UNIQUE (`email`);