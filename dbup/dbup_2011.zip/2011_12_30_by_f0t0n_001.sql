DROP TABLE IF EXISTS `bk_stripe_customer`;
CREATE TABLE `bk_stripe_customer` (
 `customer_id` varchar(255) NOT NULL COMMENT 'Stripe customer ID (PK, varchar)',
 `user_id` bigint(20) unsigned NOT NULL COMMENT 'BugKick user''s ID (FK, index bigint)',
 `company_id` bigint(20) unsigned NOT NULL COMMENT 'BugKick company''s ID (FK, unique bigint)',
 `plan_id` tinyint(3) unsigned NOT NULL COMMENT 'Stripe plan''s ID (index)',
 `payment_interval` int(10) unsigned NOT NULL,
 `last_payment_time` bigint(20) unsigned NOT NULL,
 `is_canceled` tinyint(1) unsigned NOT NULL DEFAULT '0', 
 `notified_at` bigint(20) unsigned NULL DEFAULT NULL,
 PRIMARY KEY (`customer_id`),
 KEY `user_id` (`user_id`),
 KEY `plan_id` (`plan_id`),
 KEY `payment_interval` (`payment_interval`),
 KEY `last_payment_time` (`last_payment_time`),
 KEY `is_canceled` (`is_canceled`),
 UNIQUE KEY `company_id` (`company_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stripe customers';