alter table `bk_user` add column `tickets_per_page` int default 30 null;
alter table `bk_user` add column `ticket_update_return` int default 1 null;
