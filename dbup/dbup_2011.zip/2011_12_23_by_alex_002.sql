ALTER TABLE `bk_company` ADD `company_top_logo` VARCHAR( 255 ) NOT NULL ,
ADD `company_color` VARCHAR( 7 ) NOT NULL;

ALTER TABLE `bk_user` CHANGE `use_wysiwyg` `use_wysiwyg` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '0';

UPDATE `bk_company` SET `company_url` = 'http://bugkick.com' WHERE `bk_company`.`company_id` =14 LIMIT 1 ;
UPDATE `bk_company` SET `company_url` = 'http://chaitsi123.com' WHERE `bk_company`.`company_id` =37 LIMIT 1 ;