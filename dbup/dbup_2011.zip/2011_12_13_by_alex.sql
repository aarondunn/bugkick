CREATE TABLE IF NOT EXISTS `bk_user_by_project` (
`user_id` BIGINT( 20 ) NOT NULL ,
`project_id` BIGINT( 20 ) NOT NULL ,
INDEX ( `user_id` , `project_id` )
) ENGINE = MYISAM ;
ALTER TABLE `bk_user_by_project` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;