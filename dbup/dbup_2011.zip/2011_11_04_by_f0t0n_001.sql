RENAME TABLE
	`bug` TO `bk_bug`,
	`comment` TO `bk_comment`,
	`company` TO `bk_company`,
	`label` TO `bk_label`,
	`log` TO `bk_log`,
	`log_action` TO `bk_log_action`,
	`look_and_feel` TO `bk_look_and_feel`,
	`page` TO `bk_page`,
	`status` TO `bk_status`,
	`tbl_migration` TO `bk_tbl_migration`,
	`user` TO `bk_user`,
	`user_by_company` TO `bk_user_by_company`;


CREATE TABLE `bk_project` (
	`project_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The unique identifier of the project',
	`company_id` int(10) unsigned NOT NULL COMMENT 'The identifier of project''s company',
	`name` varchar(255) NOT NULL COMMENT 'The project''s name',
	`description` text COMMENT 'The project''s description (optional)',
	`logo` varchar(255) DEFAULT NULL COMMENT 'The name of the project''s logo-file (optional)',
	`home_page` varchar(255) DEFAULT NULL COMMENT 'The URL of project''s home page (optional)',
	PRIMARY KEY (`project_id`),
	KEY `company_id` (`company_id`),
	KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `bugs2`.`bk_project` 
	(`project_id`, `company_id`, `name`, `description`, `logo`, `home_page`) 
VALUES 
	(NULL, '14', 'BugKick', 'The best bug-tracker in the near future.', NULL, 'http://bugkick.com');


ALTER TABLE `bk_bug` 
	ADD `project_id` BIGINT UNSIGNED NOT NULL COMMENT 'The project to which this bug (ticket) belongs.' AFTER `id` ,
	ADD INDEX ( `project_id` );


UPDATE `bk_bug` SET `project_id` = '1' WHERE 1;


ALTER TABLE `bk_bug` 
	ADD `prev_id` INT UNSIGNED NOT NULL COMMENT 'Previous bug''s identifier' AFTER `id` ,
	ADD `next_id` INT UNSIGNED NOT NULL COMMENT 'Next bug''s identifier' AFTER `prev_id`;


ALTER TABLE `bk_bug` 
	ADD `number` INT UNSIGNED NOT NULL COMMENT 'The number of bug.' AFTER `id` ,
	ADD INDEX ( `number` );


ALTER TABLE `bk_bug` ADD INDEX ( `prev_id` );
ALTER TABLE `bk_bug` ADD INDEX ( `next_id` );


ALTER TABLE `bk_bug` ENGINE = InnoDB;


START TRANSACTION;
	UPDATE `bk_bug` SET 
		`next_id` = `id` + 1, 
		`prev_id` = `id` - 1
	WHERE 1;
	SELECT @min:= MIN(`id`) FROM `bk_bug`;
	SELECT @max:= MAX(`id`) FROM `bk_bug`;
	UPDATE `bk_bug` SET `prev_id` = 0 WHERE `id` = @min;
	UPDATE `bk_bug` SET `next_id` = 0 WHERE `id` = @max;
COMMIT;


START TRANSACTION;
	CREATE TEMPORARY TABLE `bk_bug_tmp` SELECT * FROM `bk_bug`;
	UPDATE `bk_bug` AS `t` SET 
	`t`.`number` = (
		SELECT COUNT(`id`) FROM `bk_bug_tmp` AS `tmp`
		WHERE `tmp`.`id` <= `t`.`id`
	);
	DROP TABLE `bk_bug_tmp`;
COMMIT;