CREATE TABLE IF NOT EXISTS `look_and_feel` (
  `name` varchar(255) NOT NULL COMMENT 'The name of look-and-feel',
  `css_file` varchar(255) NOT NULL COMMENT 'Style-sheet file that contains the styles of this look-and-feel scheme',
  `img_preview` varchar(255) NOT NULL,
  PRIMARY KEY (`name`),
  KEY `css_file` (`css_file`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Site look and feel schemes';

INSERT INTO `look_and_feel` (`name`, `css_file`, `img_preview`) VALUES
('Black Linen', 'body__black-Linen.css', 'black-Linen_100x100px.png'),
('Bright Squares', 'body__bright_squares.css', 'bright_squares_100x100px.png'),
('Cork #1', 'body__cork_1.css', 'cork_1_100x100px.png'),
('Old Mathematics', 'body__old_mathematics.css', 'old_mathematics_100x100px.png'),
('Soft Wallpaper', 'body__soft_wallpaper.css', 'soft_wallpaper_100x100px.png'),
('Default', 'body__default.css', '');

ALTER TABLE `user` 
	ADD `look_and_feel` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci 
	NULL DEFAULT NULL 
	COMMENT 'User''s look-and-feel preference' 
	AFTER `email_preference` ,
	ADD INDEX (`look_and_feel`);