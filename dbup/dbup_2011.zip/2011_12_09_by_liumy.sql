Alter table `bk_company` Add Column `account_type` tinyint(2) default 0;
UPDATE `bk_company` SET account_type =1 WHERE company_name = 'Bugkick';