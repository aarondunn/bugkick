UPDATE `bk_bug` SET
    `priority_order` = `id`
WHERE 1;