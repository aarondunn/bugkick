ALTER TABLE `bk_bug` ADD `priority_order` BIGINT( 20 ) NOT NULL ,
ADD INDEX ( `priority_order` )