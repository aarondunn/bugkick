CREATE TABLE `bk_tmp_file` (
	`id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The unique identifier of temporary file (PK)',
	`path` varchar(255) NOT NULL COMMENT 'The path relative to ''webroot.tmp''',
	`created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'The time of file creation',
	PRIMARY KEY (`id`),
	UNIQUE KEY `path` (`path`),
	KEY `created_at` (`created_at`)
) 
ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Temporary files';