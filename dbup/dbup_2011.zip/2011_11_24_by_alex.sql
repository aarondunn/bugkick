ALTER TABLE `bk_bug` ADD `notified` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '0',
ADD INDEX ( `notified` )