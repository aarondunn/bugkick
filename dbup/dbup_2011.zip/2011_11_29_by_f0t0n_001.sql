CREATE TABLE `bk_bug_by_label` (
 `bug_id` int(10) unsigned NOT NULL,
 `label_id` int(10) unsigned NOT NULL,
 KEY `bug_id` (`bug_id`),
 KEY `label_id` (`label_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `bk_bug_by_user` (
 `bug_id` int(10) unsigned NOT NULL,
 `user_id` int(10) unsigned NOT NULL,
 KEY `bug_id` (`bug_id`),
 KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `bk_bug_by_label`
	SELECT `id`, `label_id`
	FROM `bk_bug`;

INSERT INTO `bk_bug_by_user`
	SELECT `id`, `user_id`
	FROM `bk_bug`;