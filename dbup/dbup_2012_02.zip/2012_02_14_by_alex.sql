ALTER TABLE `bk_company` ADD `account_plan` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL AFTER `account_type` ,
ADD INDEX ( `account_plan` );
UPDATE `bk_company` SET `account_plan` = 'ultimate_month' WHERE `bk_company`.`company_id` =14 LIMIT 1 ;