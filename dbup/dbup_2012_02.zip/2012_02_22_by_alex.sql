CREATE TABLE `bk_project_by_group` (
`project_id` BIGINT UNSIGNED NOT NULL ,
`group_id` BIGINT UNSIGNED NOT NULL ,
INDEX ( `project_id` , `group_id` )
) ENGINE = MYISAM CHARACTER SET utf8 COLLATE utf8_general_ci;