ALTER TABLE `bk_label` ADD `pre_created` TINYINT UNSIGNED NOT NULL DEFAULT '0',
ADD INDEX ( `pre_created` );

UPDATE `bk_label` SET `pre_created` = '1' WHERE `bk_label`.`name` = 'Feature'
OR `bk_label`.`name` = 'Bug'
OR `bk_label`.`name` = 'Enhancement'
OR `bk_label`.`name` = 'Proposal'
OR `bk_label`.`name` = 'Design' ;