ALTER TABLE  `bk_status`
    ADD  `is_visible_by_default` TINYINT( 1 ) UNSIGNED
    NOT NULL DEFAULT  '1'
    AFTER  `status_color`;

UPDATE `bk_status` 
    SET `is_visible_by_default` = '0'
    WHERE 1
    AND `label` = 'On Hold';