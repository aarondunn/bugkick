ALTER TABLE  `bk_user` 
    ADD  `invited_by_id` INT( 11 ) UNSIGNED 
    NULL DEFAULT NULL 
    AFTER  `inviteToken` ,
    ADD INDEX (  `invited_by_id` );