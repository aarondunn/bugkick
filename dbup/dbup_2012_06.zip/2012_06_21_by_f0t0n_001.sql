ALTER TABLE  `bk_notification`
    ADD  `bug_id` INT( 11 ) UNSIGNED
    NULL DEFAULT NULL
    AFTER  `user_id` ,
    ADD INDEX (  `bug_id` );