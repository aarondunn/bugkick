ALTER TABLE  `bk_user` 
    ADD  `encryption_algorithm` TINYINT( 1 ) UNSIGNED 
    NOT NULL DEFAULT  '1' 
    AFTER  `salt`;