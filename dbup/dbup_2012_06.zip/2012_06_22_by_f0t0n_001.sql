ALTER TABLE  `bk_user` 
	CHANGE  `ticket_update_return`  
	`ticket_update_return` TINYINT( 1 ) 
	UNSIGNED 
	NOT NULL 
	DEFAULT  '2';