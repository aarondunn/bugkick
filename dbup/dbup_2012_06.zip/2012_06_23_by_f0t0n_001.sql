ALTER TABLE  `bk_user` 
    CHANGE  `userStatus`  
        `userStatus` TINYINT( 1 ) 
        NOT NULL DEFAULT  '1' 
        COMMENT  '0-invited,1- active,2 -rejected, 3-deleted';