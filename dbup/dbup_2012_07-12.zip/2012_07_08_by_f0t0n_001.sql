CREATE TABLE `bk_github_user` (
    `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
    `login` varchar(255) NOT NULL,
    `html_url` varchar(255) NOT NULL,
    `avatar_url` text NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE  `bk_user`
    ADD  `github_auth_token` CHAR( 40 )
        CHARACTER SET utf8 COLLATE utf8_general_ci
        NULL DEFAULT NULL
        COMMENT  'The authorization token retrieved from GitHub during OAuth authorization process.'
        AFTER  `encryption_algorithm`;

ALTER TABLE  `bk_user`
    ADD  `github_user_id` INT( 11 ) UNSIGNED
        NULL DEFAULT NULL
        COMMENT  'FK(bk_github_user)'
        AFTER  `github_auth_token` ,
    ADD INDEX (  `github_user_id` );

ALTER TABLE  `bk_project`
    ADD  `github_user_id` INT( 11 ) UNSIGNED
        NULL DEFAULT NULL
        COMMENT  'FK(bk_github_user)'
        AFTER  `archived` ,
    ADD  `github_repo` VARCHAR( 255 )
        CHARACTER SET utf8 COLLATE utf8_general_ci
        NULL DEFAULT NULL
        AFTER  `github_user_id`;

ALTER TABLE  `bk_project` ADD INDEX (  `github_repo` );

ALTER TABLE  `bk_project`
    ADD  `translate_tickets` TINYINT( 1 ) UNSIGNED
        NOT NULL DEFAULT  '0'
        COMMENT  'Whether bugkick should translate the tickets and comments to GitHub Issues or not.'
        AFTER  `github_repo` ,
    ADD INDEX (  `translate_tickets` );