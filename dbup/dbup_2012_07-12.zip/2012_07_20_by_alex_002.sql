ALTER TABLE  `bk_user` CHANGE  `isadmin`  `isadmin` TINYINT( 1 ) NULL DEFAULT NULL COMMENT  'Company admin';

ALTER TABLE  `bk_user` ADD  `is_global_admin` TINYINT UNSIGNED NOT NULL DEFAULT  '0' AFTER  `isadmin` ,
ADD INDEX (  `is_global_admin` );

ALTER TABLE  `bk_user` CHANGE  `is_global_admin`  `is_global_admin` TINYINT( 3 )
 UNSIGNED NOT NULL DEFAULT  '0' COMMENT  'Global Bugkick site admin';

 UPDATE  `bugs2`.`bk_user` SET  `is_global_admin` =  '1' WHERE  `bk_user`.`user_id` =90;
 UPDATE  `bugs2`.`bk_user` SET  `is_global_admin` =  '1' WHERE  `bk_user`.`user_id` =93;
 UPDATE  `bugs2`.`bk_user` SET  `is_global_admin` =  '1' WHERE  `bk_user`.`user_id` =92;