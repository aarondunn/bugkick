CREATE TABLE `bk_invite` (
 `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
 `company_id` bigint(20) unsigned NOT NULL,
 `project_id` bigint(20) unsigned NOT NULL,
 `user_id` bigint(20) unsigned NOT NULL,
 `token` char(40) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `company_id` (`company_id`),
 KEY `project_id` (`project_id`),
 KEY `user_id` (`user_id`),
 KEY `token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE  `bk_invite`
    ADD  `invited_by_id` BIGINT( 20 ) UNSIGNED
        NOT NULL
        COMMENT  'The ID of user who made this invite.'
        AFTER  `user_id` ,
    ADD INDEX (  `invited_by_id` );