ALTER TABLE  `bk_bug`
    CHANGE  `isarchive`
    `isarchive` TINYINT( 1 ) UNSIGNED
    NULL
    DEFAULT  NULL;

ALTER TABLE  `bk_bug` CHANGE  `isarchive`
    `isarchive` TINYINT( 1 ) UNSIGNED
    NULL DEFAULT NULL;

UPDATE `bk_bug` SET
    isarchive = NULL
    WHERE isarchive = 0;