ALTER TABLE  `bk_github_user`
    ADD  `is_active` TINYINT( 1 ) UNSIGNED
        NOT NULL DEFAULT  '1'
        AFTER  `id` ,
    ADD INDEX (  `is_active` );