CREATE TABLE IF NOT EXISTS `bk_user_block` (
  `user_ip` varchar(255) NOT NULL,
  `block_to` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `count_entry` int(11) NOT NULL,
  `first_entry` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

