ALTER TABLE  `bk_notification` CHANGE  `user_id`  `user_id` INT( 10 ) UNSIGNED NOT NULL COMMENT 'This is a user who will see this notification(owner or assigned person)';
ALTER TABLE  `bk_notification` ADD  `changer_id` INT UNSIGNED NOT NULL COMMENT  'User who made change(left comment, changed a ticket, etc)',
ADD INDEX (  `changer_id` );