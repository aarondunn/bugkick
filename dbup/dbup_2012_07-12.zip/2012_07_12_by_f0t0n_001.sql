CREATE TABLE `bk_github_issue` (
 `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
 `number` bigint(20) unsigned NOT NULL,
 `html_url` varchar(255) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE  `bk_bug`
    ADD  `github_issue_id` BIGINT( 20 ) UNSIGNED
        NULL DEFAULT NULL
        COMMENT  'FK(bk_github_issue)' AFTER  `id` ,
    ADD INDEX (  `github_issue_id` );