CREATE TABLE `bk_site_settings` (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`invites_module` TINYINT( 1 ) UNSIGNED NOT NULL COMMENT  'Defines if invites module is enabled',
`invites_count` INT UNSIGNED NOT NULL COMMENT  'Limit of invites per user',
`invites_limit` TINYINT( 1 ) UNSIGNED NOT NULL COMMENT  'Defines if we limit number of available invites per user'
) ENGINE = INNODB;

INSERT INTO `bk_site_settings` (
`id` ,
`invites_module` ,
`invites_count` ,
`invites_limit`
)
VALUES (
NULL ,  '0',  '5',  '1'
);