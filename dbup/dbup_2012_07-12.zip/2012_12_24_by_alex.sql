ALTER TABLE  `bk_bug` ADD  `api_user_email` VARCHAR( 255 ) NOT NULL
 COMMENT  'Email of the user who submitted a bug using API ' AFTER `is_created_with_api`;