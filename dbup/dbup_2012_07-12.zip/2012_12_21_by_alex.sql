CREATE TABLE IF NOT EXISTS `bk_coupon` (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`code` VARCHAR( 255 ) NOT NULL COMMENT  'Coupon code',
`enabled` TINYINT UNSIGNED NOT NULL ,
`period` INT NOT NULL COMMENT  'Defines how much time for free (in seconds)',
INDEX (  `code` ,  `enabled` )
) ENGINE = INNODB;

ALTER TABLE  `bk_company` ADD  `coupon_id` INT UNSIGNED NOT NULL ,
ADD INDEX (  `coupon_id` );

ALTER TABLE  `bk_company` ADD  `coupon_expires_at` INT UNSIGNED NOT NULL ,
ADD INDEX (  `coupon_expires_at` );