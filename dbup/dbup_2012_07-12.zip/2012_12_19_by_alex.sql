CREATE TABLE IF NOT EXISTS `bk_domains_blacklist` (
`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`domain` VARCHAR( 255 ) NOT NULL COMMENT  'Email services that are prohibited to register on Bugkick',
INDEX (  `domain` )
) ENGINE = INNODB;

INSERT INTO `bk_domains_blacklist` (`id` ,`domain`)
VALUES
(NULL ,  'mailinator.com'
),(
NULL ,  'zippymail.info'
), (
NULL ,  'mailinator2.com'
),(
NULL ,  'sendspamhere.com'
), (
NULL ,  'chammy.info'
),(
NULL ,  'notmailinator.com'
), (
NULL ,  'mailinator.net'
),(
NULL ,  'letthemeatspam.com'
), (
NULL ,  'tradermail.info'
), (
NULL ,  'dcemail.com'
), (
NULL ,  'mail2world.com'
),(
NULL ,  'bigstring.com'
), (
NULL ,  'hushmail.com'
),(
NULL ,  'tempinbox.com'
), (
NULL ,  'lavabit.com'
), (
NULL ,  'techemail.com'
);
