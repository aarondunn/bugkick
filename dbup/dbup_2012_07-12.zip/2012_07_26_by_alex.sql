#FOREIGN KEYS#


START TRANSACTION;

-- Table bk_bug_by_label
    /* Removing bk_bug_by_label when bk_bug is removed */
        ALTER TABLE  `bk_bug` CHANGE  `id`  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT;
        ALTER TABLE  `bk_bug_by_label` CHANGE  `bug_id`  `bug_id` BIGINT UNSIGNED NOT NULL;

        ALTER TABLE  `bk_bug_by_label` ADD FOREIGN KEY (  `bug_id` ) REFERENCES `bk_bug` (
        `id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;

    /* Removing bk_bug_by_label when bk_label is removed */
        ALTER TABLE  `bk_label` CHANGE  `label_id`  `label_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT;
        ALTER TABLE  `bk_bug_by_label` CHANGE  `label_id`  `label_id` BIGINT UNSIGNED NOT NULL;

        /*removing wrong records*/
        DELETE bk_bug_by_label.*
        FROM  `bk_bug_by_label`
        LEFT OUTER JOIN bk_label ON bk_bug_by_label.label_id = bk_label.label_id
        WHERE bk_label.label_id IS NULL;

        ALTER TABLE  `bk_bug_by_label` ADD FOREIGN KEY ( `label_id` ) REFERENCES `bk_label` (
        `label_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT;
-- END Table bk_bug_by_label


-- Table bk_bug_by_user
    /* Removing bk_bug_by_user when bk_bug is removed */
        ALTER TABLE  `bk_bug_by_user` CHANGE  `bug_id`  `bug_id` BIGINT UNSIGNED NOT NULL;

        ALTER TABLE  `bk_bug_by_user` ADD FOREIGN KEY (  `bug_id` ) REFERENCES  `bk_bug` (
        `id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;

    /* Removing bk_bug_by_user when bk_user is removed */
        ALTER TABLE  `bk_bug_by_user` CHANGE  `user_id`  `user_id` BIGINT UNSIGNED NOT NULL;
        ALTER TABLE  `bk_user` CHANGE  `user_id`  `user_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT;

        /*removing wrong records*/
        DELETE bk_bug_by_user.*
        FROM  `bk_bug_by_user`
        LEFT OUTER JOIN bk_user ON bk_bug_by_user.user_id = bk_user.user_id
        WHERE bk_user.user_id IS NULL;

        ALTER TABLE  `bk_bug_by_user` ADD FOREIGN KEY (  `user_id` ) REFERENCES `bk_user` (
        `user_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_bug_by_user


-- Table bk_bug
    /* Removing bk_bug when bk_project is removed */
        ALTER TABLE  `bk_bug` ADD FOREIGN KEY (  `project_id` ) REFERENCES `bk_project` (
        `project_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;

    /* Removing bk_bug when bk_company is removed */
        ALTER TABLE  `bk_bug` ADD INDEX (  `company_id` );

        /*removing wrong records*/
        DELETE bk_bug . *
        FROM  `bk_bug`
        LEFT OUTER JOIN bk_company ON bk_bug.company_id = bk_company.company_id
        WHERE bk_company.company_id IS NULL;

        ALTER TABLE  `bk_bug` ADD FOREIGN KEY (  `company_id` ) REFERENCES `bk_company` (
        `company_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT;
-- END Table bk_bug


-- Table bk_comment
    /* Removing bk_comment when bk_bug is removed */
        ALTER TABLE  `bk_comment` CHANGE  `comment_id`  `comment_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT;
        ALTER TABLE  `bk_comment` CHANGE  `bug_id`  `bug_id` BIGINT UNSIGNED NOT NULL;

        /*removing wrong records*/
        DELETE bk_comment . *
        FROM  `bk_comment`
        LEFT OUTER JOIN bk_bug ON bk_comment.bug_id = bk_bug.id
        WHERE bk_bug.id IS NULL;

        ALTER TABLE  `bk_comment` ADD FOREIGN KEY (  `bug_id` ) REFERENCES  `bk_bug` (
        `id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_comment


-- Table bk_bug_changelog
    /* Removing bk_bug_changelog when bk_bug is removed */
        ALTER TABLE  `bk_bug_changelog` CHANGE  `bug_id`  `bug_id` BIGINT UNSIGNED NOT NULL;
        ALTER TABLE  `bk_bug_changelog` CHANGE  `id`  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT;
        ALTER TABLE  `bk_bug_changelog` ADD INDEX (  `user_id` );

        /*removing wrong records*/
        DELETE bk_bug_changelog . *
        FROM  `bk_bug_changelog`
        LEFT OUTER JOIN bk_bug ON bk_bug_changelog.bug_id = bk_bug.id
        WHERE bk_bug.id IS NULL;

        ALTER TABLE  `bk_bug_changelog` ADD FOREIGN KEY (  `bug_id` ) REFERENCES `bk_bug` (
        `id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_bug_changelog


-- Table bk_filter
    /* Removing bk_filter when bk_user is removed */
        ALTER TABLE  `bk_filter` CHANGE  `user_id`  `user_id` BIGINT UNSIGNED NOT NULL;

        ALTER TABLE  `bk_filter` ADD FOREIGN KEY (  `user_id` ) REFERENCES  `bk_user` (
        `user_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_filter


-- Table bk_label
    /* Removing bk_label when bk_company is removed */
        ALTER TABLE  `bk_label` ADD INDEX (  `company_id` );

        /*removing wrong records*/
        DELETE bk_label.*
        FROM  `bk_label`
        LEFT OUTER JOIN bk_company ON bk_label.company_id = bk_company.company_id
        WHERE bk_company.company_id IS NULL;

        ALTER TABLE  `bk_label` ADD FOREIGN KEY (  `company_id` ) REFERENCES  `bk_company` (
        `company_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_label


-- Table bk_label_by_project
    /* Removing bk_label_by_project when bk_label is removed */
        ALTER TABLE  `bk_label_by_project` ADD INDEX (  `project_id` );
        ALTER TABLE  `bk_label_by_project` CHANGE  `label_id`  `label_id` BIGINT UNSIGNED NOT NULL;
        ALTER TABLE  `bk_label_by_project` CHANGE  `project_id`  `project_id` BIGINT UNSIGNED NOT NULL;

        /*removing wrong records*/
        DELETE bk_label_by_project.*
        FROM  `bk_label_by_project`
        LEFT OUTER JOIN bk_label ON bk_label_by_project.label_id = bk_label.label_id
        WHERE bk_label.label_id IS NULL;

        ALTER TABLE  `bk_label_by_project` ADD FOREIGN KEY (  `label_id` ) REFERENCES `bk_label` (
        `label_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;

    /* Removing bk_label_by_project when bk_project is removed */
        ALTER TABLE  `bk_label_by_project` ADD FOREIGN KEY (  `project_id` ) REFERENCES `bk_project` (
        `project_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_label_by_project

-- Table bk_notification
    /* Removing bk_notification when bk_bug is removed */
        ALTER TABLE  `bk_notification` CHANGE  `bug_id`  `bug_id` BIGINT UNSIGNED NULL DEFAULT NULL;

        /*removing wrong records*/
        DELETE bk_notification.*
        FROM  `bk_notification`
        LEFT OUTER JOIN bk_bug ON bk_notification.bug_id = bk_bug.id
        WHERE bk_bug.id IS NULL;

        ALTER TABLE  `bk_notification` ADD FOREIGN KEY (  `bug_id` ) REFERENCES `bk_bug` (
        `id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_notification

-- Table bk_project
    /* Removing bk_project when bk_company is removed */
        ALTER TABLE  `bk_project` CHANGE  `company_id`  `company_id`
        INT( 11 ) NOT NULL COMMENT  'The identifier of project''s company';

        ALTER TABLE  `bk_project` ADD FOREIGN KEY (  `company_id` ) REFERENCES `bk_company` (
        `company_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_project

-- Table bk_settings_by_project
    /* Removing bk_settings_by_project when bk_project is removed */
        ALTER TABLE  `bk_settings_by_project` CHANGE  `project_id`  `project_id` BIGINT UNSIGNED NOT NULL;

        ALTER TABLE  `bk_settings_by_project` ADD FOREIGN KEY (  `project_id` ) REFERENCES `bk_project` (
        `project_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_settings_by_project

-- Table bk_settings_by_user
    /* Removing bk_settings_by_user when bk_user is removed */
        ALTER TABLE  `bk_settings_by_user` CHANGE  `user_id`  `user_id` BIGINT UNSIGNED NOT NULL;

        /*removing wrong records*/
        DELETE bk_settings_by_user.*
        FROM  `bk_settings_by_user`
        LEFT OUTER JOIN bk_user ON bk_settings_by_user.user_id = bk_user.user_id
        WHERE bk_user.user_id IS NULL;

        ALTER TABLE  `bk_settings_by_user` ADD FOREIGN KEY (  `user_id` ) REFERENCES `bk_user` (
        `user_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_settings_by_user

-- Table bk_status
    /* Removing bk_status when bk_company is removed */
        /*removing wrong records*/
        DELETE bk_status.*
        FROM  `bk_status`
        LEFT OUTER JOIN bk_company ON bk_status.company_id = bk_company.company_id
        WHERE bk_company.company_id IS NULL;

        ALTER TABLE  `bk_status` ADD FOREIGN KEY (  `company_id` ) REFERENCES `bk_company` (
        `company_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_status



-- Table bk_user_by_company
    /* Removing bk_user_by_company when bk_company is removed */
        ALTER TABLE  `bk_user_by_company` CHANGE  `user_id`  `user_id` BIGINT UNSIGNED NOT NULL;

        /*removing wrong records*/
        DELETE  bk_user_by_company.*
        FROM  `bk_user_by_company`
        LEFT OUTER JOIN bk_user ON bk_user_by_company.user_id = bk_user.user_id
        WHERE bk_user.user_id IS NULL;

        ALTER TABLE  `bk_user_by_company` ADD FOREIGN KEY (  `user_id` ) REFERENCES `bk_user` (
        `user_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;

        /*removing wrong records*/
        DELETE  bk_user_by_company.*
        FROM  `bk_user_by_company`
        LEFT OUTER JOIN bk_company ON bk_user_by_company.company_id = bk_company.company_id
        WHERE bk_company.company_id IS NULL;

        ALTER TABLE  `bk_user_by_company` ADD FOREIGN KEY (  `company_id` ) REFERENCES `bk_company` (
        `company_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_user_by_company


-- Table bk_user_by_email_preference
    /* Removing bk_user_by_email_preference when bk_user is removed */
        ALTER TABLE  `bk_user_by_email_preference` CHANGE  `user_id`  `user_id` BIGINT UNSIGNED NOT NULL;

        /*removing wrong records*/
        DELETE bk_user_by_email_preference.*
        FROM  `bk_user_by_email_preference`
        LEFT OUTER JOIN bk_user ON bk_user_by_email_preference.user_id = bk_user.user_id
        WHERE bk_user.user_id IS NULL;

        ALTER TABLE  `bk_user_by_email_preference` ADD FOREIGN KEY (  `user_id` ) REFERENCES `bk_user` (
        `user_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_user_by_email_preference


-- Table bk_user_by_project
    /* Removing bk_user_by_project when bk_user or bk_project is removed */
        ALTER TABLE  `bk_user_by_project` CHANGE  `user_id`  `user_id` BIGINT( 20 ) UNSIGNED NOT NULL;
        ALTER TABLE  `bk_user_by_project` CHANGE  `project_id`  `project_id` BIGINT( 20 ) UNSIGNED NOT NULL;
        ALTER TABLE  `bk_user_by_project` ADD INDEX (  `project_id` );

        ALTER TABLE  `bk_user_by_project` ADD FOREIGN KEY (  `user_id` ) REFERENCES `bk_user` (
        `user_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;

        ALTER TABLE  `bk_user_by_project` ADD FOREIGN KEY (  `project_id` ) REFERENCES `bk_project` (
        `project_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_user_by_project


-- Table bk_user_by_group
    /* Removing bk_user_by_group when bk_user or bk_user_group is removed */
        ALTER TABLE  `bk_user_by_group` CHANGE  `user_id`  `user_id` BIGINT( 20 ) UNSIGNED NOT NULL;
        ALTER TABLE  `bk_user_by_group` CHANGE  `group_id`  `group_id` BIGINT( 20 ) UNSIGNED NOT NULL;
        ALTER TABLE  `bk_user_group` CHANGE  `group_id`  `group_id` BIGINT( 20 ) UNSIGNED NOT NULL AUTO_INCREMENT;

        ALTER TABLE  `bk_user_by_group` ADD FOREIGN KEY (  `user_id` ) REFERENCES `bk_user` (
        `user_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;

        ALTER TABLE  `bk_user_by_group` ADD FOREIGN KEY (  `group_id` ) REFERENCES `bk_user_group` (
        `group_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_user_by_group


-- Table bk_user_group
    /* Removing bk_user_group when bk_company is removed */
        ALTER TABLE  `bk_user_group` CHANGE  `project_id`  `project_id` BIGINT( 20 ) UNSIGNED
        NULL DEFAULT NULL COMMENT 'If project_id is empty, the group available for all projects';

        ALTER TABLE  `bk_user_group` ADD FOREIGN KEY (  `company_id` ) REFERENCES `bk_company` (
        `company_id`
        ) ON DELETE CASCADE ON UPDATE RESTRICT ;
-- END Table bk_user_group


COMMIT;