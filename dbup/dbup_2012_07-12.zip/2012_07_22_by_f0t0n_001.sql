ALTER TABLE  `bk_user_by_company`
    ADD  `user_status` TINYINT( 1 ) UNSIGNED
        NOT NULL DEFAULT  '1'
        COMMENT  'The user''s status in company'
        AFTER  `company_id` ,
    ADD INDEX (  `user_status` );

UPDATE `bk_user_by_company` AS `ubc` SET
`ubc`.`user_status` = (
    SELECT `u`.`userStatus` FROM `bk_user` AS `u` WHERE 1
    AND `u`.`user_id` = `ubc`.`user_id`
);