CREATE TABLE bk_yii_session
(
    id CHAR(32) PRIMARY KEY,
    expire INTEGER,
    data TEXT
);

ALTER TABLE  `bk_yii_session` ADD INDEX (  `expire` );