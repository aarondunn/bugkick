ALTER TABLE  `bk_user_by_company`
    ADD  `is_admin` TINYINT( 1 ) UNSIGNED
        NOT NULL DEFAULT  '0'
        COMMENT  'Defines is the user an admin of this company.'
        AFTER  `company_id` ,
    ADD INDEX (  `is_admin` );

ALTER TABLE  `bk_user_by_project`
    ADD  `is_admin` TINYINT( 1 ) UNSIGNED
        NOT NULL DEFAULT  '0'
        COMMENT  'Defines is the user an admin of this project.'
        AFTER  `project_id` ,
    ADD INDEX (  `is_admin` );