ALTER TABLE  `bk_company` ADD  `owner_id` BIGINT UNSIGNED NOT NULL ,
ADD INDEX (  `owner_id` );

ALTER TABLE  `bk_user` ADD  `pro_status` TINYINT UNSIGNED NOT NULL DEFAULT  '0'
COMMENT 'pro_status  - means that all companies that the user has, were upgraded to ''Pro'' plan from admin panel',
ADD INDEX (  `pro_status` );