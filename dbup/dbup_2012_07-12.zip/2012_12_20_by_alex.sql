ALTER TABLE  `bk_topic` ADD  `archived` TINYINT NOT NULL DEFAULT  '0',
ADD INDEX (  `archived` )