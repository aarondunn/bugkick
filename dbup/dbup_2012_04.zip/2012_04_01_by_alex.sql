ALTER TABLE  `bk_project` ADD  `archived` BOOL NOT NULL DEFAULT  '0',
ADD INDEX (  `archived` )